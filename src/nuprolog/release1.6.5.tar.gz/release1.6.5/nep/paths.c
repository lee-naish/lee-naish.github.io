/*
 * Please note that this code is the property of
 * the University of Melbourne and is Copyright 1988 by it.
 * 
 * All rights are reserved.
 *
 * Author: Jeff Schultz
 */

#define NPATHS 6

char *PATHS[NPATHS] = { HEADER, BIN, WAKE, NEP, NUBIN, NULIB };
