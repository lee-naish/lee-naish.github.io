%	$Header: unegpp.pl,v 1.1 85/11/25 19:37:36 lee Exp $

%	NU-Negation preprocessor.  Translates from NU-Negation constructs
%	into UNSOUND standard DEC-10 constructs.  Doesnt do any checking.

?- ['npp.pl', 'unegtrf.pl'].
