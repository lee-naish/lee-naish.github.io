%	$Header: negpp.pl,v 1.1 85/11/25 19:36:58 lee Exp $

%	NU-Negation preprocessor.  Translates from NU-Negation constructs
%	into sound low level primitives.  Also checks for illegal
%	quantified global variables.

?- ['npp.pl', 'negtrf.pl'].
