/*
 * rdesc.c  -  deductive database package (record descriptor operations)
 *
 * Copyright (c) 1985,1986,1987, The University of Melbourne
 */

#include "simc.h"

