/*
 * sdesc.h  -  deductive database package (segment descriptor definitions)
 *
 * Copyright (c) 1985,1986,1987, The University of Melbourne
 */


