/*
 * split.h  -  deductive database package (splitting definitions)
 *
 * Copyright (c) 1985,1986,1987, The University of Melbourne
 */
