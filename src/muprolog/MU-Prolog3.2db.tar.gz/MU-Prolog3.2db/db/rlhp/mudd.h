#define DB_QY		'q'	/* partial match query - only one answer */
#define DB_QYALL	'Q'	/* partial match query - find all answers */
#define DB_RT		'r'	/* retract */
#define	DB_RTALL	'R'	/* retractall */
#define DB_ASS		'a'	/* synchronous assert */
#define DB_ASA		'A'	/* asynchronous assert */
